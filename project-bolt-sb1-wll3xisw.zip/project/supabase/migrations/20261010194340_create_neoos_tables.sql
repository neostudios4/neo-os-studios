/*
# Create NeoOS core tables (single-tenant, no auth)

## Summary
NeoOS is a browser-based OS simulator with no sign-in screen. Currently all state lives in
browser localStorage. This migration creates three tables to persist that data server-side:
user settings, installed apps/games, and text editor documents.

## New Tables

1. neoos_settings
   - Stores key/value pairs for user preferences (username, accent color, wallpaper,
     text scaling, setup-complete flag, etc.).
   - id (uuid, PK)
   - key (text, unique) — the setting name (e.g. 'neoos_username', 'neoos_accent')
   - value (text) — the setting value serialized as a string
   - updated_at (timestamptz) — last modification time

2. neoos_installed_apps
   - Stores installed game/app entries from the App Store so they survive across sessions.
   - id (uuid, PK)
   - app_key (text, unique) — internal key (e.g. 'agario', 'slitherio')
   - app_name (text) — display name
   - app_icon (text) — emoji or icon
   - app_color (text) — hex color string
   - app_type (text) — 'canvas' or 'iframe'
   - app_desc (text) — description
   - app_data (jsonb) — flexible JSON for any extra metadata
   - installed_at (timestamptz)

3. neoos_documents
   - Stores text editor content so it persists across reloads.
   - id (uuid, PK)
   - name (text) — document label (default 'untitled')
   - content (text) — the document body
   - created_at (timestamptz)
   - updated_at (timestamptz)

## Security
- RLS enabled on all three tables.
- Policies use TO anon, authenticated (no sign-in screen in this app).
- All CRUD operations allowed for anon + authenticated since data is intentionally shared.
*/

-- 1. neoos_settings
CREATE TABLE IF NOT EXISTS neoos_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value text NOT NULL DEFAULT '',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE neoos_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_settings" ON neoos_settings;
CREATE POLICY "anon_select_settings" ON neoos_settings FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_settings" ON neoos_settings;
CREATE POLICY "anon_insert_settings" ON neoos_settings FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_settings" ON neoos_settings;
CREATE POLICY "anon_update_settings" ON neoos_settings FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_settings" ON neoos_settings;
CREATE POLICY "anon_delete_settings" ON neoos_settings FOR DELETE
  TO anon, authenticated USING (true);

-- 2. neoos_installed_apps
CREATE TABLE IF NOT EXISTS neoos_installed_apps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  app_key text UNIQUE NOT NULL,
  app_name text NOT NULL DEFAULT '',
  app_icon text NOT NULL DEFAULT '',
  app_color text NOT NULL DEFAULT '',
  app_type text NOT NULL DEFAULT 'canvas',
  app_desc text NOT NULL DEFAULT '',
  app_data jsonb DEFAULT '{}',
  installed_at timestamptz DEFAULT now()
);

ALTER TABLE neoos_installed_apps ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_apps" ON neoos_installed_apps;
CREATE POLICY "anon_select_apps" ON neoos_installed_apps FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_apps" ON neoos_installed_apps;
CREATE POLICY "anon_insert_apps" ON neoos_installed_apps FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_apps" ON neoos_installed_apps;
CREATE POLICY "anon_update_apps" ON neoos_installed_apps FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_apps" ON neoos_installed_apps;
CREATE POLICY "anon_delete_apps" ON neoos_installed_apps FOR DELETE
  TO anon, authenticated USING (true);

-- 3. neoos_documents
CREATE TABLE IF NOT EXISTS neoos_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL DEFAULT 'untitled',
  content text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE neoos_documents ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_documents" ON neoos_documents;
CREATE POLICY "anon_select_documents" ON neoos_documents FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_documents" ON neoos_documents;
CREATE POLICY "anon_insert_documents" ON neoos_documents FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_documents" ON neoos_documents;
CREATE POLICY "anon_update_documents" ON neoos_documents FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_documents" ON neoos_documents;
CREATE POLICY "anon_delete_documents" ON neoos_documents FOR DELETE
  TO anon, authenticated USING (true);

-- Indexes for faster lookups
CREATE INDEX IF NOT EXISTS idx_neoos_settings_key ON neoos_settings(key);
CREATE INDEX IF NOT EXISTS idx_neoos_installed_apps_key ON neoos_installed_apps(app_key);
